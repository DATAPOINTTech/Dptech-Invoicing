<?php

declare(strict_types=1);

function generate_invoice_pdf(array $invoice_data): string
{
    $companyName = !empty($invoice_data['company_name']) ? $invoice_data['company_name'] : (getenv('COMPANY_NAME') ?: 'DATAPOINT Technologies');
    $companyAddress = !empty($invoice_data['company_address']) ? $invoice_data['company_address'] : (getenv('COMPANY_ADDRESS') ?: 'Hyderabad, Sindh');
    $companyPhone = !empty($invoice_data['company_phone']) ? $invoice_data['company_phone'] : (getenv('COMPANY_PHONE') ?: '');

    $lines = [
        $companyName,
        $companyAddress . ($companyPhone ? ' | ' . $companyPhone : ''),
        '------------------------------------------------------------',
        'TAX SALES INVOICE',
        'Invoice #: ' . ($invoice_data['invoice_no'] ?? ''),
        'Date: ' . ($invoice_data['invoice_date'] ?? ''),
        'Due Date: ' . ($invoice_data['due_date'] ?? ''),
        'Client: ' . ($invoice_data['client_name'] ?? ''),
        '------------------------------------------------------------',
        'Items:',
    ];

    if (!empty($invoice_data['items'])) {
        foreach ($invoice_data['items'] as $item) {
            $description = trim((string) ($item['description'] ?? ''));
            $quantity = (string) ($item['quantity'] ?? 0);
            $unitPrice = number_format((float) ($item['unit_price'] ?? 0), 2);
            $lineTotal = number_format((float) ($item['total_price'] ?? 0), 2);
            $lines[] = "- {$description} x {$quantity} @ PKR {$unitPrice} = PKR {$lineTotal}";
        }
    }

    $lines[] = '------------------------------------------------------------';
    $lines[] = 'Subtotal: PKR ' . number_format((float) ($invoice_data['subtotal'] ?? 0), 2);
    if (!empty($invoice_data['tax_amount'])) {
        $taxRate = $invoice_data['tax_rate'] ?? 17;
        $lines[] = "GST ({$taxRate}%): PKR " . number_format((float) $invoice_data['tax_amount'], 2);
    }
    $lines[] = 'TOTAL AMOUNT: PKR ' . number_format((float) ($invoice_data['total_amount'] ?? 0), 2);

    return build_pdf_string($lines);
}

function generate_estimate_pdf(array $estimate_data): string
{
    $companyName = !empty($estimate_data['company_name']) ? $estimate_data['company_name'] : (getenv('COMPANY_NAME') ?: 'DATAPOINT Technologies');
    $companyAddress = !empty($estimate_data['company_address']) ? $estimate_data['company_address'] : (getenv('COMPANY_ADDRESS') ?: 'Hyderabad, Sindh');
    $companyPhone = !empty($estimate_data['company_phone']) ? $estimate_data['company_phone'] : (getenv('COMPANY_PHONE') ?: '');
    $companyNtn = !empty($estimate_data['company_ntn']) ? ' | NTN: ' . $estimate_data['company_ntn'] : '';

    $markup = isset($estimate_data['markup_percent']) && (float) $estimate_data['markup_percent'] > 0
        ? ' (Quotation Option ' . number_format((float) $estimate_data['markup_percent'], 1) . '%)'
        : '';

    $lines = [
        strtoupper($companyName),
        $companyAddress,
        ($companyPhone ? 'Phone: ' . $companyPhone : '') . $companyNtn,
        '============================================================',
        'ESTIMATE / QUOTATION' . $markup,
        'Estimate #: ' . ($estimate_data['estimate_no'] ?? ''),
        'Date: ' . ($estimate_data['estimate_date'] ?? ''),
        'Valid Until: ' . ($estimate_data['valid_until'] ?? ''),
        'Client: ' . ($estimate_data['client_name'] ?? 'Valued Customer'),
        '============================================================',
        'Itemized Scope & Pricing:',
    ];

    if (!empty($estimate_data['items'])) {
        foreach ($estimate_data['items'] as $item) {
            $description = trim((string) ($item['description'] ?? ''));
            $quantity = (string) ($item['quantity'] ?? 0);
            $unit = (string) ($item['unit'] ?? 'pcs');
            $unitPrice = number_format((float) ($item['unit_price'] ?? 0), 2);
            $lineTotal = number_format((float) ($item['total_price'] ?? 0), 2);
            $lines[] = "• {$description} ({$quantity} {$unit}) @ PKR {$unitPrice} = PKR {$lineTotal}";
        }
    }

    $lines[] = '------------------------------------------------------------';
    $lines[] = 'Subtotal: PKR ' . number_format((float) ($estimate_data['subtotal'] ?? 0), 2);
    if (!empty($estimate_data['discount_amount'])) {
        $lines[] = 'Discount: PKR ' . number_format((float) $estimate_data['discount_amount'], 2);
    }
    if (!empty($estimate_data['tax_amount'])) {
        $taxRate = $estimate_data['tax_rate'] ?? 17;
        $lines[] = "GST ({$taxRate}%): PKR " . number_format((float) $estimate_data['tax_amount'], 2);
    }
    $lines[] = 'GRAND TOTAL: PKR ' . number_format((float) ($estimate_data['total_amount'] ?? 0), 2);
    $lines[] = '============================================================';
    $lines[] = 'Thank you for considering our quotation!';

    return build_pdf_string($lines);
}

function build_pdf_string(array $lines): string
{
    $content = "BT\n/F1 11 Tf\n50 780 Td\n";
    foreach ($lines as $index => $line) {
        $safeLine = str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], $line);
        if ($index === 0) {
            $content .= "({$safeLine}) Tj\n";
        } else {
            $content .= "0 -16 Td\n({$safeLine}) Tj\n";
        }
    }
    $content .= "ET\n";

    $length = strlen($content);

    $pdf = "%PDF-1.4\n";
    $pdf .= "1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n";
    $pdf .= "2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n";
    $pdf .= "3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 842] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>\nendobj\n";
    $pdf .= "4 0 obj\n<< /Length {$length} >>\nstream\n{$content}endstream\nendobj\n";
    $pdf .= "5 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj\n";
    $pdf .= "xref\n0 6\n0000000000 65535 f \n0000000010 00000 n \n0000000069 00000 n \n0000000132 00000 n \n0000000262 00000 n \n0000000329 00000 n \n";
    $pdf .= "trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n398\n%%EOF\n";

    return $pdf;
}
